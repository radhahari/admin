<?php include('process.php') ?>

<html>
<head>
  <title>Admin Login</title>
  <link rel="stylesheet" href="styles.css">
<script>
</script>
</head>
<body>
  <form method="post" action="admin_login.php" id="register_form">
  	<h1>Admin Login</h1>
  	<div <?php if (isset($name_error)): ?> class="form_error" <?php endif ?> >
	  <input type="text" name="username" placeholder="Username" id="uname" autofocus="autofocus" value="<?php echo $username; ?>">
	  <?php if (isset($name_error)): ?>
	  	<span><?php echo $name_error; ?></span>
	  <?php endif ?>
  
	</div>
  	<div>
  		<input type="password"  placeholder="Password" name="password">
  	</div>
		<div>
  		<button type="submit" name="register" id="reg_btn">LOGIN</button>
  	</div>
  </form>
<div <?php if (isset($name_error)): ?> class="form_error" <?php endif ?> >
  </body>
</html>
