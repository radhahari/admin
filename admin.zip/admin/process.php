<?php 
  $db = mysqli_connect('localhost', 'root', '', 'rhdmzyzf_eshop_db');
  $username = "";
  $password = "";
  if (isset($_POST['register'])) {
  	$username = $_POST['username'];
  	
  	$password = $_POST['password'];

	$sql="SELECT admin_id FROM admin WHERE admin_uname='$username' && admin_pass='$password' ";
	$query=mysqli_query($db,$sql);
	$row=mysqli_fetch_array($query,MYSQLI_ASSOC);
	
	$count=mysqli_num_rows($query);
	if($count==1)
	{
         header("location:admin_login.php");	
	}
	else
	{
         	$name_error= "Your Login Name or Password is invalid";

	}
}
	
		
?>
