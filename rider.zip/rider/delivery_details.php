<html>
<head>
<style>
table th, td {
  padding: 4px;
  text-align: left;
}
table h1
{
text-align:center;
}

</style>
</head>
<?php
session_start();
$shopId=$_POST['shopid'];
$riderId=$_POST['riderid'];
$conn = mysqli_connect('localhost', 'root', '', 'rhdmzyzf_eshop_db');
$query="SELECT * FROM shop where shop_id='$shopId' ";
if($res=mysqli_query($conn,$query))
{
	while ($row = mysqli_fetch_array($res))
	{
	
?>
<table border="8px">
<tr><td colspan='2'><h1>Delivery Details</h1> </td></tr>
<tr><td>Shop Name </td><td><?php echo $row['shop_name']; ?></td></tr>
<tr><td>Shop Address </td><td><?php echo $row['shop_address']; ?></td></tr>
<tr><td>Shop Landmark</td><td><?php echo $row['shop_landmark']; ?></td></tr>
<tr><td>Shop City </td><td><?php echo $row['shop_city']; ?></td></tr>
<tr><td>Shop Category </td><td><?php echo $row['shop_catogery']; ?></td></tr>

<tr><td>Delivery From</td><td><?php echo $row['delivery_from']; ?></td></tr>
<tr><td>Delivery To</td><td><?php echo $row['delivery_to']; ?></td></tr>
<?php
$qry="SELECT order_id FROM rider_payment WHERE rider_id='$riderId' ";
if($res1=mysqli_query($conn,$qry))
{
	while($row1=mysqli_fetch_array($res1))
	{
		$orderId=$row1["order_id"];
	
		$qry="SELECT * FROM delivery WHERE order_id='$orderId' ";
		if($res2=mysqli_query($conn,$qry))
		{
			while($row2=mysqli_fetch_array($res2))
			{
				?>
<tr><td>Delivery Amount</td><td><?php echo $row2['amount']; ?></td></tr>
<tr><td>Payment Status/td><td><?php echo $row2['payment_status']; ?></td></tr>

<?php
			}
		}
	}

}
?>
</table>

<?php
	}
}
else
{
echo "No records";

}
?>
</html>