<?php 
  $db = mysqli_connect('localhost', 'root', '', 'rhdmzyzf_eshop_db');
  $username = "";
  $password = "";
  if (isset($_POST['register'])) {
  	$username = $_POST['username'];
  	
  	$password = $_POST['password'];

	$sql="SELECT rider_id,shop_id FROM rider WHERE rider_username='$username' && rider_password='$password' ";
	$query=mysqli_query($db,$sql);
	$row=mysqli_fetch_array($query,MYSQLI_ASSOC);
	$shopId=$row['shop_id'];
	$riderId=$row['rider_id'];
	$count=mysqli_num_rows($query);
	if($count==1)
	{
        	 header("location:delivery_details.php?shopid='$shopId' && riderid='$riderId' ");	
	}
	else
	{
        	$name_error= "Your Login Name or Password is invalid";
	}

	
	}

?>
