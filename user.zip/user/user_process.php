<?php 
  $db = mysqli_connect('localhost', 'root', '', 'rhdmzyzf_eshop_db');
  $email = "";
  $password = "";
  if (isset($_POST['register'])) {
  	$email = $_POST['email'];
  	
  	$password = $_POST['password'];

	$sql="SELECT user_id FROM user WHERE user_email='$email' && user_password='$password' ";
	$query=mysqli_query($db,$sql);
	$row=mysqli_fetch_array($query,MYSQLI_ASSOC);
	$id=$row["user_id"];
	$count=mysqli_num_rows($query);
	if($count==1)
	{
         header("location:order_details.php?id='$id' ");	
	}
	else
	{
         	$name_error= "Your Login Name or Password is invalid";

	}

}
	
		
?>
