<?php
session_start();
$userId=$_GET['id'];
$conn = mysqli_connect('localhost', 'root', '', 'rhdmzyzf_eshop_db');
$query="SELECT * FROM user_order WHERE user_id='$userId'";
?>
<html>
<head>

<link rel="stylesheet" href="styles.css">
<style>
th, td {
  padding: 4px;
  text-align: left;
}
table h1,
{
text-align:center;
}
</style>
</head>
<body>
<form action="billDetails.php" method="POST">
<table border='4'><tr><td colspan='2'><h1>User Order Details </h1></td></tr>
<tr><td colspan='2'><button  name="userid" value="<?php echo $userId; ?>" id="userid" >Bill</button></td></tr>
<?php
if($res=mysqli_query($conn,$query))
{
while ($row = mysqli_fetch_array($res))
{
$shopId=$row['shop_id'];
$query1="SELECT product_id,product_name,product_quantity,product_price FROM product WHERE shop_id='$shopId'";
if($res1=mysqli_query($conn,$query1))
{
	while($row1=mysqli_fetch_array($res1))
{
?>
<tr><td>Product Number</td><td><?php echo $row1['product_id']; ?></td></tr>
<tr><td>Product Name</td><td><?php echo $row1['product_name']; ?></td></tr>
<tr><td>Quantity</td><td><?php echo $row1['quantity']; ?></td></tr>
<tr><td>Price</td><td><?php echo $row1['price']; ?></td></tr>

<?php
}
}
    
  }
  mysqli_free_result($result);
}
 	
?>
</table>
</form>
</body>
</html>