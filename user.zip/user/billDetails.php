<html>
<head>
<link rel="stylesheet" href="styles.css">
<style>
table th, td {
  padding: 4px;
  text-align: left;
}
table h1,
{
text-align:center;
}
</style>

</head>

<?php
session_start();
if(isset($_POST['userid']))
{
$uid=$_POST['userid'];
$conn = mysqli_connect('localhost', 'root', '', 'rhdmzyzf_eshop_db');
$query="SELECT * FROM bill WHERE user_id='$uid'";

if($res=mysqli_query($conn,$query))
{
while($row=mysqli_fetch_array($res))
{
?>
<table><tr><td colspan='2'>Bill Details</td></tr></table>
<tr><td>Order Id</td><td><?php echo $row['order_id']; ?></td></tr>
<tr><td>Amount</td><td><?php echo $row['amount']; ?></td></tr>
<tr><td>Discount </td><td><?php echo $row['discount']; ?></td></tr>
<tr><td>Tax and GST</td><td><?php echo $row['txt_gst']; ?></td></tr>
<tr><td>Final Amount</td><td><?php echo $row['final_amount']; ?></td></tr>
<?php
}

}
else
{
//echo "no records";
}
}
?>

